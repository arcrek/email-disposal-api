<?php
declare(strict_types=1);

// Test all endpoints for basic functionality
echo "=== Email API Endpoint Testing ===\n\n";

$baseUrl = 'https://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
if (isset($_SERVER['REQUEST_SCHEME'])) {
    $baseUrl = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
}

$endpoints = [
    'Main API' => '/api/email.php',
    'Statistics' => '/admin/stats.php',
    'Load Emails (Paginated)' => '/admin/load_emails_paginated.php?page=1&limit=10',
    'Load Emails (File)' => '/admin/load_emails.php',
];

function testEndpoint($name, $url) {
    echo "Testing {$name}:\n";
    echo "URL: {$url}\n";
    
    $context = stream_context_create([
        'http' => [
            'timeout' => 10,
            'ignore_errors' => true
        ]
    ]);
    
    $result = @file_get_contents($url, false, $context);
    
    if ($result === false) {
        echo "❌ FAILED: Could not connect\n\n";
        return false;
    }
    
    $json = json_decode($result, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "❌ FAILED: Invalid JSON response\n";
        echo "Response: " . substr($result, 0, 200) . "...\n\n";
        return false;
    }
    
    if (isset($json['success'])) {
        if ($json['success']) {
            echo "✅ SUCCESS\n";
            if (isset($json['email'])) {
                echo "   Email: " . $json['email'] . "\n";
            }
            if (isset($json['stats'])) {
                echo "   Stats: " . json_encode($json['stats']) . "\n";
            }
            if (isset($json['data']['total'])) {
                echo "   Total emails: " . $json['data']['total'] . "\n";
            }
        } else {
            echo "❌ FAILED: " . ($json['message'] ?? 'Unknown error') . "\n";
            if (isset($json['debug'])) {
                echo "   Debug: " . $json['debug'] . "\n";
                echo "   File: " . ($json['file'] ?? 'Unknown') . "\n";
                echo "   Line: " . ($json['line'] ?? 'Unknown') . "\n";
            }
        }
    } else {
        echo "❌ FAILED: Unexpected response format\n";
        echo "Response: " . substr($result, 0, 200) . "...\n";
    }
    
    echo "\n";
    return isset($json['success']) && $json['success'];
}

// Test database connection first
echo "Testing Database Connection:\n";
try {
    require_once 'api/config.php';
    $manager = new EmailManager();
    $stats = $manager->getStats();
    echo "✅ Database connection successful\n";
    echo "   Total emails in DB: " . $stats['total'] . "\n";
    echo "   Available: " . $stats['available'] . "\n";
    echo "   Locked: " . $stats['locked'] . "\n\n";
} catch (Exception $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "\n";
    echo "   File: " . $e->getFile() . "\n";
    echo "   Line: " . $e->getLine() . "\n\n";
    exit(1);
}

// Test all endpoints
$passed = 0;
$total = count($endpoints);

foreach ($endpoints as $name => $endpoint) {
    $url = $baseUrl . $endpoint;
    if (testEndpoint($name, $url)) {
        $passed++;
    }
}

echo "=== TEST SUMMARY ===\n";
echo "Passed: {$passed}/{$total}\n";
echo "Status: " . ($passed === $total ? "✅ ALL TESTS PASSED" : "❌ SOME TESTS FAILED") . "\n";

if ($passed === $total) {
    echo "\n🎉 Your Email API is working correctly!\n";
    echo "You can now:\n";
    echo "- Call /api/email to get random emails\n";
    echo "- Use /admin/ to manage your email database\n";
    echo "- Run performance_benchmark.php to test scalability\n";
} else {
    echo "\n⚠️  Some endpoints need attention. Check the error details above.\n";
}
?>
