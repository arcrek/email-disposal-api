<?php
declare(strict_types=1);

// Performance Benchmark Script for 1M+ Email System
require_once 'api/config.php';

set_time_limit(300); // 5 minute limit
ini_set('memory_limit', '512M');

echo "=== Email API Performance Benchmark ===\n\n";

try {
    $manager = new EmailManager();
    
    // Test 1: Database Performance
    echo "Test 1: Database Performance\n";
    echo "============================\n";
    
    $start = microtime(true);
    $stats = $manager->getStats();
    $dbTime = microtime(true) - $start;
    
    echo "Total emails: " . number_format($stats['total']) . "\n";
    echo "Available: " . number_format($stats['available']) . "\n";
    echo "Locked: " . number_format($stats['locked']) . "\n";
    echo "Stats query time: " . round($dbTime * 1000, 2) . " ms\n\n";
    
    // Test 2: Random Email Selection Performance
    echo "Test 2: Random Email Selection (10 requests)\n";
    echo "===========================================\n";
    
    $times = [];
    for ($i = 0; $i < 10; $i++) {
        $start = microtime(true);
        $email = $manager->getRandomEmail();
        $time = microtime(true) - $start;
        $times[] = $time * 1000; // Convert to ms
        
        echo "Request " . ($i + 1) . ": " . round($time * 1000, 2) . " ms";
        if ($email) {
            echo " - Got: " . substr($email, 0, 20) . "...\n";
        } else {
            echo " - No email available\n";
        }
    }
    
    $avgTime = array_sum($times) / count($times);
    $maxTime = max($times);
    $minTime = min($times);
    
    echo "\nPerformance Summary:\n";
    echo "Average response time: " . round($avgTime, 2) . " ms\n";
    echo "Min response time: " . round($minTime, 2) . " ms\n";
    echo "Max response time: " . round($maxTime, 2) . " ms\n";
    echo "Target: < 50ms (" . ($avgTime < 50 ? "PASS" : "FAIL") . ")\n\n";
    
    // Test 3: Pagination Performance
    echo "Test 3: Pagination Performance\n";
    echo "===============================\n";
    
    $pageTests = [100, 500, 1000];
    foreach ($pageTests as $pageSize) {
        $start = microtime(true);
        $result = $manager->getEmailsPaginated(1, $pageSize);
        $time = microtime(true) - $start;
        
        echo "Page size {$pageSize}: " . round($time * 1000, 2) . " ms\n";
    }
    
    // Test 4: Search Performance
    echo "\nTest 4: Search Performance\n";
    echo "==========================\n";
    
    $searchQueries = ['gmail', 'test', '@example.com', 'user1'];
    foreach ($searchQueries as $query) {
        $start = microtime(true);
        $result = $manager->getEmailsPaginated(1, 100, $query);
        $time = microtime(true) - $start;
        
        echo "Search '{$query}': " . round($time * 1000, 2) . " ms - {$result['total']} results\n";
    }
    
    // Test 5: Concurrent Request Simulation
    echo "\nTest 5: Lock Conflict Test\n";
    echo "===========================\n";
    
    $emails = [];
    $conflicts = 0;
    
    // Simulate 20 concurrent requests
    for ($i = 0; $i < 20; $i++) {
        $email = $manager->getRandomEmail();
        if ($email) {
            if (in_array($email, $emails)) {
                $conflicts++;
                echo "CONFLICT: Duplicate email detected: {$email}\n";
            } else {
                $emails[] = $email;
            }
        }
    }
    
    echo "Unique emails retrieved: " . count($emails) . "\n";
    echo "Conflicts detected: {$conflicts}\n";
    echo "Conflict rate: " . ($conflicts > 0 ? "FAIL" : "PASS") . "\n\n";
    
    // Test 6: Memory Usage
    echo "Test 6: Memory Usage\n";
    echo "====================\n";
    
    $memoryStart = memory_get_usage(true);
    $peakMemory = memory_get_peak_usage(true);
    
    echo "Current memory usage: " . formatBytes($memoryStart) . "\n";
    echo "Peak memory usage: " . formatBytes($peakMemory) . "\n";
    echo "Memory limit: " . ini_get('memory_limit') . "\n\n";
    
    // Test 7: Large Batch Processing
    if ($stats['total'] < 100000) {
        echo "Test 7: Batch Processing (Simulated)\n";
        echo "====================================\n";
        
        // Simulate bulk insert performance
        $testEmails = [];
        for ($i = 0; $i < 1000; $i++) {
            $testEmails[] = "test{$i}_" . time() . "@benchmark.com";
        }
        
        $start = microtime(true);
        $count = $manager->saveEmailsBulk($testEmails);
        $time = microtime(true) - $start;
        
        echo "Bulk insert 1000 emails: " . round($time * 1000, 2) . " ms\n";
        echo "Rate: " . round(1000 / $time) . " emails/second\n";
        
        // Cleanup test emails safely
        try {
            $stmt = $manager->pdo->prepare("DELETE FROM emails WHERE email LIKE '%@benchmark.com'");
            $stmt->execute();
            echo "Test emails cleaned up\n\n";
        } catch (Exception $e) {
            echo "Cleanup warning: " . $e->getMessage() . "\n\n";
        }
    }
    
    // Final Assessment
    echo "=== PERFORMANCE ASSESSMENT ===\n";
    echo "API Response Time: " . ($avgTime < 50 ? "✓ PASS" : "✗ FAIL") . " (Target: <50ms)\n";
    echo "Lock Conflicts: " . ($conflicts == 0 ? "✓ PASS" : "✗ FAIL") . " (Target: 0)\n";
    echo "Memory Usage: " . ($peakMemory < 256*1024*1024 ? "✓ PASS" : "✗ FAIL") . " (Target: <256MB)\n";
    
    $overallPass = ($avgTime < 50) && ($conflicts == 0) && ($peakMemory < 256*1024*1024);
    echo "\nOVERALL: " . ($overallPass ? "✓ SYSTEM READY FOR 1M+ EMAILS" : "✗ NEEDS OPTIMIZATION") . "\n";
    
} catch (Exception $e) {
    echo "Error during benchmark: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
}

function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    
    for ($i = 0; $bytes > 1024; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}
